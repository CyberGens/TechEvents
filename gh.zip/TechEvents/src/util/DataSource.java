/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import entities.Event;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.EventService;

/**
 *
 * @author Ghathenus
 */
public class DataSource {

    private String url = "jdbc:mysql://localhost:3306/techevents";
    private String username = "root";
    private String password = "";
    private Connection connexion;
    private static DataSource instance;

    private DataSource() {
        try {
            connexion = DriverManager.getConnection(url, username, password);
            System.out.println("Connexion établie!");
        } catch (SQLException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static DataSource getInstance() {
        if (instance == null) {
            instance = new DataSource();
        }
        return instance;

    }

    public Connection getConnexion() {
        return connexion;
    }
    
    

    public static void main(String[] args) {
        DataSource dsl = DataSource.getInstance();
        System.out.println(dsl);
        Date d = Date.valueOf("1995-11-07");
        
        Event e = new Event (1,"Ghassen",d,"Japan",700,"Google","TheBest","Conference","free");
        EventService es = new EventService();
        es.update(e);
         
    
    }

}
