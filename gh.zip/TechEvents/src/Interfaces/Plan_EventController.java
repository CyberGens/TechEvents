/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import entities.Event;
import entities.User;
import entities.planned_event;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import service.EventService;
import service.UserService;
import service.InscriptionService;

/**
 * FXML Controller class
 *
 * @author Ghathenus
 */
public class Plan_EventController implements Initializable {

    @FXML
    private DatePicker Set_Date;
    @FXML
    private TextField Event_Name;
    @FXML
    private ComboBox<String> Interest;
    @FXML
    private CheckBox Reminder;
    @FXML
    private Button Plan_Event_but;
    @FXML
    private TextField Id_User;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Interest.getItems().removeAll(Interest.getItems());
Interest.getItems().addAll("Very","a little","not much");
Interest.getSelectionModel().select("a little");

        Plan_Event_but.setOnAction(e -> {
            Event ev = new Event();
            EventService es = new EventService();
            User u = new User();
            UserService us = new UserService();
            Date date = Date.valueOf(Set_Date.getValue());

            int d = Integer.parseInt(Event_Name.getText());
            int m = Integer.parseInt(Id_User.getText());
            ev = es.getById(d);
            u=us.getById(m);
            planned_event pe = new planned_event(ev, u, d + m + 10, (String) Interest.getValue());
            InscriptionService ps = new InscriptionService();

            ps.insertPST(pe);
            Parent root;

            try {
                root = FXMLLoader.load(getClass().getResource("CreateEve.fxml"));
            } catch (IOException ex) {
                Logger.getLogger(CreateEveController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

    }

}
