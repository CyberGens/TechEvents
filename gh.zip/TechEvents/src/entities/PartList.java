/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.util.Objects;

/**
 *
 * @author Ghathenus
 */
public class PartList {
    private Event ID_event;
    private planned_event Id_inscription;
    private Date date;

    public PartList(Event ID_event, planned_event Id_inscription, Date date) {
        this.ID_event = ID_event;
        this.Id_inscription = Id_inscription;
        this.date = date;
    }

    public Event getID_event() {
        return ID_event;
    }

    public planned_event getId_inscription() {
        return Id_inscription;
    }

    public Date getDate() {
        return date;
    }

    public void setID_event(Event ID_event) {
        this.ID_event = ID_event;
    }

    public void setId_inscription(planned_event Id_inscription) {
        this.Id_inscription = Id_inscription;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.ID_event);
        hash = 71 * hash + Objects.hashCode(this.Id_inscription);
        hash = 71 * hash + Objects.hashCode(this.date);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PartList other = (PartList) obj;
        if (!Objects.equals(this.ID_event, other.ID_event)) {
            return false;
        }
        if (!Objects.equals(this.Id_inscription, other.Id_inscription)) {
            return false;
        }
        if (!Objects.equals(this.date, other.date)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PartList{" + "ID_event=" + ID_event + ", Id_inscription=" + Id_inscription + ", date=" + date + '}';
    }
    
    
    
    
}
