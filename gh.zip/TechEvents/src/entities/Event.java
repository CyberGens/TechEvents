/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.IOException;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Ghathenus
 */
public class Event  {
    private int ID_event;
    private String Name;
    private Date Date;
    private String location;
    private int max_number;
    private String sponsors;
    private String description ;
    private String category;
private String fin_status;


    public Event() {
    }

    public Event (int ID_event, String Name, Date Date, String location, int max_number, String sponsors, String description, 
            String category, String fin_status) {
       this.ID_event = ID_event;
        this.Name = Name;
        this.Date= Date;
        this.location = location;
        this.max_number = max_number;
        this.sponsors = sponsors;
        this.description= description;
        this.category = category;
        this.fin_status = fin_status;
    }
    

    public int getID_event() {
        return ID_event;
    }

    public String getName() {
        return Name;
    }

    public Date getDate() {
        return Date;
    }

    public String getLocation() {
        return location;
    }

    public int getMax_Number() {
        return max_number;
    }

    public String getSponsors() {
        return sponsors;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public String getFin_Status() {
        return fin_status;
    }

    public void setID_event(int ID_event) {
        this.ID_event = ID_event;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setDate(Date Date) {
        this.Date = Date;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setMax_number(int max_number) {
        this.max_number = max_number;
    }

    public void setSponsors(String sponsors) {
        this.sponsors = sponsors;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setFin_Status(String fin_status) {
        this.fin_status = fin_status;
    }

    @Override
    public String toString() {
        return "Event{" + "ID_event=" + ID_event + ", Name=" + Name + ", Date=" + Date + ", location=" + location + ", max_number=" + max_number + ", sponsors=" + sponsors + ", description=" + description + ", category=" + category + ", fin_status=" + fin_status + '}';
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int hashCode() {
        return super.hashCode(); //To change body of generated methods, choose Tools | Templates.
    }
public void Event(Stage stage) throws Exception {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("Event.fxml"));
        } catch (IOException ex) {
            Logger.getLogger(Event.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
     public void CreateEve(Stage stage) throws Exception {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("CreateEve.fxml"));
        } catch (IOException ex) {
            Logger.getLogger(Event.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
     public void ViewEvents(Stage stage) throws Exception {
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getResource("ViewEvents.fxml"));
        } catch (IOException ex) {
            Logger.getLogger(Event.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    
}

