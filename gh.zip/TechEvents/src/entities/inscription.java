/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.util.Objects;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class inscription  {
    private Event Id_event;
    private User Id;
    private int Id_insciription;
   
    public inscription() {
    }

    public inscription(Event Id_event, User Id, int Id_insciription) {
        this.Id_event = Id_event;
        this.Id = Id;
        this.Id_insciription = Id_insciription;
    }

    public Event getId_event() {
        return Id_event;
    }

    public User getId() {
        return Id;
    }

    public int getId_insciription() {
        return Id_insciription;
    }

    public void setId_event(Event  Id_event) {
        this.Id_event = Id_event;
    }

    public void setId(User Id) {
        this.Id = Id;
    }

    public void setId_insciription(int Id_insciription) {
        this.Id_insciription = Id_insciription;
    }

    @Override
    public String toString() {
        return "inscription{" + "Id_event=" + Id_event + ", Id=" + Id + ", Id_insciription=" + Id_insciription + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.Id_event);
        hash = 59 * hash + Objects.hashCode(this.Id);
        hash = 59 * hash + this.Id_insciription;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final inscription other = (inscription) obj;
        if (this.Id_insciription != other.Id_insciription) {
            return false;
        }
        if (!Objects.equals(this.Id_event, other.Id_event)) {
            return false;
        }
        if (!Objects.equals(this.Id, other.Id)) {
            return false;
        }
        return true;
    }

   
    }

   
  
    
