/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Event;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.DataSource;

/**
 *
 * @author Ghathenus
 */
public class EventService implements IService<Event> {

    private Connection cnx;
    private Statement ste;
    private PreparedStatement pst;
    private ResultSet rs;
    private List<Event> Event;
        public EventService() {
        cnx=DataSource.getInstance().getConnexion(); 
    }

    @Override
    public void insertPST(Event t) {
        String req = "Insert into event (ID_event,Name,Date,"
                + "Location,Max_Number,Sponsors,Description,Category,Fin_Status) values (?,?,?,?,?,?,?,?,?)";
        try {
            pst = cnx.prepareStatement(req);
            pst.setInt(1, t.getID_event());
            pst.setString(2, t.getName());
            pst.setDate(3, t.getDate());
            pst.setString(4, t.getLocation());
            pst.setInt(5, t.getMax_Number());
            pst.setString(6, t.getSponsors());
            pst.setString(7, t.getDescription());
            pst.setString(8, t.getCategory());
            pst.setString(9, t.getFin_Status());
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void delete(int id) {
        String req = "delete from Event where(ID_event=" + id + ")";
        try {
            ste = cnx.createStatement();
            ste.executeUpdate(req);
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Event t) {
        String req = "update Event set ID_event=?, Name=?,Date=?, Location=?,Max_Number=?, Sponsors=?,Description=?,Category=?,Fin_Status=?";
        try {
            pst = cnx.prepareStatement(req);
            pst.setInt(1, t.getID_event());
            pst.setString(2, t.getName());
            pst.setDate(3, t.getDate());
            pst.setString(4, t.getLocation());
            pst.setInt(5, t.getMax_Number());
            pst.setString(6, t.getSponsors());
            pst.setString(7, t.getDescription());
            pst.setString(8, t.getCategory());
            pst.setString(9, t.getFin_Status());

            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @return
     */
    @Override
    public List<Event> getAll() {
        String req = "select * from Event";
        List<Event> list = new ArrayList<>();

        try {
            ste = cnx.createStatement();
            rs = ste.executeQuery(req);
            while (rs.next()) {
                list.add(new Event(rs.getInt("ID_event"), rs.getString("Name"), rs.getDate("Date"),
                        rs.getString("Location"), rs.getInt("Max_Number"), rs.getString("Sponsors"), rs.getString("Description"),
                        rs.getString("Category"), rs.getString("Fin_Status")));

            }
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    
    
    
    public ArrayList<Event> getByName(String Name) {
        String req = "select * from Event where Name like '"+Name+"%'";
        List<Event> list = new ArrayList<>();

        try {
            ste = cnx.createStatement();
            rs = ste.executeQuery(req);
            while (rs.next()) {
                list.add(new Event(rs.getInt("ID_event"), rs.getString("Name"), rs.getDate("Date"),
                        rs.getString("Location"), rs.getInt("Max_Number"), rs.getString("Sponsors"), rs.getString("Description"),
                        rs.getString("Category"), rs.getString("Fin_Status")));

            }
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return (ArrayList<Event>) list;
    }
    
    
    
    

    public Event getById(int id) {
        String req = "select * from Event where ID_Event=?";
        Event event = new Event();
        {
            try {
                pst = cnx.prepareStatement(req);

                pst.setInt(1, id);

                rs = pst.executeQuery();

                while (rs.next()) {
                    event = new Event(rs.getInt("ID_event"), rs.getString("Name"), rs.getDate("Date"),
                            rs.getString("Location"), rs.getInt("Max_Number"), rs.getString("Sponsors"), rs.getString("Description"),
                            rs.getString("Category"), rs.getString("Fin_Status"));
                }
            } catch (SQLException ex) {
                Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
            }

            return event;
        }
    }
    

    @Override
    public Event getById(Event t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
